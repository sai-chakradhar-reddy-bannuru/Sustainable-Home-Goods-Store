import sqlite3

# Connect to your SQLite database. Replace 'your_database.db' with your database file name.
conn = sqlite3.connect('db.sqlite3')

# Create a cursor object using the cursor method
cursor = conn.cursor()

# SQL statement to drop a table. Replace 'table_name' with the name of your table.
sql_query = "DROP TABLE IF EXISTS goods_address;"

try:
    # Execute the SQL command to drop the table
    cursor.execute(sql_query)

    # Commit your changes in the database
    conn.commit()
    print("Table deleted successfully.")
except sqlite3.Error as e:
    # Roll back any changes if something goes wrong
    conn.rollback()
    print("Error occurred:", e)
finally:
    # Close the connection to the database
    conn.close()
