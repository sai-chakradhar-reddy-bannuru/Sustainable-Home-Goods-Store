from django.contrib import admin
from .models import Product, Order

class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'price']
    list_filter = ['category']
    search_fields = ['name', 'description', 'category']


class OrderAdmin(admin.ModelAdmin):
    list_display = ['product', 'buyer', 'date_purchased']
    list_filter = ['date_purchased', 'buyer']
    search_fields = ['product__name', 'buyer__username']



admin.site.register(Product, ProductAdmin)
admin.site.register(Order, OrderAdmin)

