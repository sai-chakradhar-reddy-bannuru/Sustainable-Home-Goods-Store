from django.db import models
from django.contrib.auth.models import AbstractUser
from django.conf import settings


class User(AbstractUser):
    is_admin = models.BooleanField(default=False)
    is_user = models.BooleanField(default=False)

    class Meta:
        swappable = 'AUTH_USER_MODEL'


class Product(models.Model):
    CATEGORIES = (
        ('cleaning_supplies', 'Eco-Friendly Cleaning Supplies'),
        ('home_decor', 'Sustainable Home Decor'),
        ('kitchenware', 'Eco-Friendly Kitchenware'),
        ('bedding', 'Sustainable Bedding and Linens'),
        ('personal_care', 'Eco-Friendly Personal Care Products'),
        ('furniture', 'Sustainable Furniture'),
        ('lighting', 'Energy Efficient Lighting'),
        ('gardening', 'Sustainable Gardening Supplies'),
        ('appliances', 'Energy Efficient Appliances'),
        ('textiles', 'Eco-Friendly Textiles'),
    )

    name = models.CharField(max_length=255)
    description = models.TextField()
    category = models.CharField(max_length=50, choices=CATEGORIES)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    image = models.TextField()

    def __str__(self):
        return self.name


class Order(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    buyer = models.ForeignKey(settings.AUTH_USER_MODEL,
                              on_delete=models.CASCADE)
    date_purchased = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.buyer.username} - {self.product.name}"

