from django.urls import path
from . import views
from django.contrib import admin
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.home, name='home'),
    path('admin/', admin.site.urls),
    path('login/', views.login_view, name='login'),
    path('signup/', views.signup_view, name='signup'),
    path('logout/', views.logout_view, name='logout'),
    path('password-reset/', views.ResetPasswordView.as_view(), name='password_reset'),
    path('password-reset-complete/', auth_views.PasswordResetCompleteView.as_view(template_name='password_reset_complete.html'),
         name='password_reset_complete'),
    path('password-reset-confirm/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(
             template_name='password_reset_confirm.html'),
         name='password_reset_confirm'),
    path('catalog/', views.ProductCatalogView, name='product_catalog'),
    path('payment/success/', views.payment_success, name='payment_success'),
    path('add-to-cart/<int:item_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/', views.cart, name='cart'),
    path('update-cart/', views.update_cart, name='update_cart'),
    path('cart-count/', views.cart_count, name='cart_count'),
    path('create-payment-intent/', views.create_checkout_session,
         name='create_checkout_session'),
    path('payment/success/', views.payment_success, name='success'),
    path('payment/cancel/', views.payment_cancel, name='cancel'),
    path('products/', views.products_detail_view, name='products_detail_view'),
    path('orders/', views.orders_detail_view, name='orders_detail_view'),
    path('product/<int:product_id>/',
         views.ProductDetailsView, name='product_details'),
         
]

