from django.views.decorators.csrf import csrf_exempt
import re
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages, auth
from django.contrib.auth import logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from .models import *
from django.http import HttpResponse
from django.urls import reverse
import stripe
from django.conf import settings
from django.http import JsonResponse
from django.utils import timezone
import uuid
from django.urls import reverse_lazy
from django.contrib.auth.views import PasswordResetView
from django.contrib.messages.views import SuccessMessageMixin
from django.contrib.auth import get_user_model
User = get_user_model()


@login_required(login_url='login')
def home(request):
    return render(request, 'index.html')


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = auth.authenticate(request, username=username, password=password)

        if user is not None:
            auth.login(request, user)
            # messages.success(request, 'You are now logged in.')
            # Replace 'home' with the name of your homepage view
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password.')

    return render(request, 'login.html')


def signup_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password']

        # Regular expression for validating the password
        password_regex = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\W)[a-zA-Z0-9\S]{8,}$'

        if len(username) < 6:
            messages.error(
                request, "Username must be at least 6 characters long")
            return redirect('signup')

        if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
            messages.error(request, "Invalid email address")
            return redirect('signup')

        # Using re.match to check if the password meets the requirements
        if not re.match(password_regex, password1):
            messages.error(
                request, "Password must be at least 8 characters long, include both uppercase and lowercase letters, and contain at least one special character.")
            return redirect('signup')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken")
            return redirect('signup')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already taken")
            return redirect('signup')

        user = User.objects.create_user(
            username=username, email=email, password=password1)
        user.save()
        messages.success(request, "New User Created")
        return redirect('signup')

    return render(request, 'signup.html')


def logout_view(request):
    logout(request)
    return redirect('home')


class ResetPasswordView(SuccessMessageMixin, PasswordResetView):
    template_name = 'password_reset.html'
    email_template_name = 'password_reset_email.html'
    subject_template_name = 'password_reset_subject.txt'
    success_message = "We've emailed you instructions for setting your password, " \
                      "if an account exists with the email you entered. You should receive them shortly." \
                      " If you don't receive an email, " \
                      "please make sure you've entered the address you registered with, and check your spam folder."
    success_url = reverse_lazy('home')


def ProductCatalogView(request):
    # Retrieve query parameters
    query = request.GET.get('query', '')
    category = request.GET.get('category', '')

    # Filter products by query if it exists
    products = Product.objects.all()
    if query:
        products = products.filter(name__icontains=query)

    # Filter products by category if it exists
    if category:
        products = products.filter(category=category)

    return render(request, 'catalog.html', {'products': products, 'categories': Product.CATEGORIES})


@login_required
def payment_success(request):
    session_ref = request.GET.get('session_ref')
    if not session_ref:
        return HttpResponse("Missing session reference.", status=400)

    # Retrieve the session or cart using the session_ref
    # This example uses Django's session framework; adapt as needed for your storage method
    order_ref = request.session.get('order_ref')
    if session_ref != order_ref:
        return HttpResponse("Invalid session reference.", status=400)

    cart = request.session.get('cart', {})
    if not cart:
        return HttpResponse("Cart is empty or session has expired.", status=400)

    # Assuming you have cart information to create an order...
    for item_id, quantity in cart.items():
        product = Product.objects.get(id=item_id)
        Order.objects.create(
            product=product,
            buyer=request.user,
            date_purchased=timezone.now()
        )

    # Optionally, clear the cart from the session
    del request.session['cart']
    del request.session['order_ref']
    request.session.modified = True

    # Redirect to a confirmation page or render a success template
    return render(request, 'payment_success.html')


@login_required
def add_to_cart(request, item_id):
    # Get existing cart or create an empty one
    cart = request.session.get('cart', {})
    cart[item_id] = cart.get(item_id, 0) + 1  # Add or increment item quantity
    request.session['cart'] = cart  # Update session cart
    request.session.modified = True  # Mark session as modified

    # Add success message to context
    context = {'success_message': 'Item added to cart successfully!'}

    # Replace with the appropriate template
    return redirect('product_catalog')


def cart(request):
    cart = request.session.get('cart', {})
    items_in_cart = []
    total_cart_price = 0

    if cart:
        for item_id, quantity in cart.items():
            item = Product.objects.get(pk=item_id)
            total_price = item.price * quantity
            total_cart_price += total_price
            items_in_cart.append({
                'item': item,
                'quantity': quantity,
                'total_price': total_price
            })

    context = {
        'cart': items_in_cart,
        'total_cart_price': total_cart_price
    }
    return render(request, 'cart.html', context)


def update_cart(request):
    item_id = request.POST.get('item_id')
    action = request.POST.get('action')
    cart = request.session.get('cart', {})

    if item_id and action:
        if action == 'add':
            cart[item_id] = cart.get(item_id, 0) + 1
        elif action == 'remove':
            if item_id in cart:
                cart[item_id] = max(0, cart.get(item_id, 0) - 1)
                if cart[item_id] == 0:
                    del cart[item_id]

    request.session['cart'] = cart
    request.session.modified = True

    return JsonResponse({'success': True})


@login_required
def cart_count(request):
    cart = request.session.get('cart', {})
    count = sum(cart.values())  # Total number of items in the cart
    return JsonResponse({'count': count})


def calculate_total_cart_price(cart):
    total_price = 0
    for item_id, quantity in cart.items():
        item = Product.objects.get(id=item_id)
        total_price += item.price * quantity
    return total_price


# Your Stripe secret key (ensure this is kept secure)
stripe.api_key = settings.STRIPE_SECRET_KEY


@login_required
def create_checkout_session(request):
    # Ensure we have a cart in the session
    cart = request.session.get('cart', {})
    if not cart:
        return JsonResponse({'error': 'Your cart is empty'}, status=400)

    # Prepare Stripe line items
    line_items = []
    for item_id, quantity in cart.items():
        product = Product.objects.get(id=item_id)
        line_item = {
            'price_data': {
                'currency': 'usd',
                'product_data': {
                    'name': product.name,
                },
                # Stripe expects the amount in cents
                'unit_amount': int(product.price * 100),
            },
            'quantity': quantity,
        }
        line_items.append(line_item)

    # Generate a unique reference for this checkout session
    order_ref = uuid.uuid4()
    request.session['order_ref'] = str(order_ref)

    # Create the Stripe Checkout Session
    try:
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=line_items,
            mode='payment',
            billing_address_collection='required',
            success_url=request.build_absolute_uri(
                reverse('payment_success')) + f"?session_ref={order_ref}",
            cancel_url=request.build_absolute_uri(reverse('cancel')),
        )
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)

    # Store the Checkout Session ID in the session for potential future use
    request.session['checkout_session_id'] = checkout_session.id

    # Return the session URL to the frontend to redirect the user to Stripe Checkout
    # return JsonResponse({'session_url': checkout_session.url})

    return redirect(checkout_session.url)
    # return JsonResponse({'session_url': checkout_session.url})


def payment_cancel(request):
    # You can add any context or logic here
    return render(request, 'payment_cancel.html')


def ProductDetailsView(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    context = {
        'product': product,
    }
    return render(request, 'product_details.html', context)

@login_required
def products_detail_view(request):
    products = Product.objects.filter(owner=request.user)
    return render(request, 'products_detail.html', {'products': products})


@login_required
def orders_detail_view(request):
    orders = Order.objects.filter(buyer=request.user)
    return render(request, 'orders_detail.html', {'orders': orders})
